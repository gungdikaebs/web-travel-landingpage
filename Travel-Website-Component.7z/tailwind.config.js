module.exports = {
    theme: {
        container: {
            center: true,
        },
    },
}